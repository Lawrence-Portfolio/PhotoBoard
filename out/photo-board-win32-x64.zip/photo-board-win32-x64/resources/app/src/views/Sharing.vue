<template>
    <div class="ready-photo-panel">
        <div class="ready-photo-panel-wrap image">
            <div class="header-panel">
                <div class="you-photo-ready-text image"></div>
            </div>
            <div class="body-panel">
                <div class="sharing-wrap">
                    <div class="send-photo-sotial-network-text image"></div>
                    <div class="qr-code image"></div>
                    <div class="scan-qr-code image"></div>
                </div>
            </div>
            <div class="footer-panel">
                <div class="footer-panel-wrap">

                    <div class="photo-zone-bishkek-text image"></div>
                </div>
            </div>
        </div>
    </div>
</template>